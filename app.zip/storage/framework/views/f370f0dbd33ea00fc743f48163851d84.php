<footer class="footer d-flex flex-column flex-md-row align-items-center justify-content-between px-4 py-3 border-top small">
    <p class="text-muted mb-1 mb-md-0">Copyright © 2022 <a href="https://www.nobleui.com" target="_blank">NobleUI</a>.</p>
    <p class="text-muted">Handcrafted With <i class="mb-1 text-primary ms-1 icon-sm" data-feather="heart"></i></p>
</footer>
<!-- partial -->

</div>
</div>

<!-- core:js -->
<script src="<?php echo e(asset('backend/assets/vendors/core/core.js')); ?>"></script>
<!-- endinject -->

<!-- Plugin js for this page -->
<script src="<?php echo e(asset('backend/assets/vendors/flatpickr/flatpickr.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/assets/vendors/apexcharts/apexcharts.min.js')); ?>"></script>
<!-- End plugin js for this page -->

<!-- inject:js -->
<script src="<?php echo e(asset('backend/assets/vendors/feather-icons/feather.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/assets/js/template.js')); ?>"></script>
<!-- endinject -->

<!-- Custom js for this page -->
<script src="<?php echo e(asset('backend/assets/js/dashboard-dark.js')); ?>"></script>
<!-- End custom js for this page -->

<!--The Toaster alert-->

<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>

<?php if(Session::has('message')): ?>
    <script>
        var type = "<?php echo e(Session::get('alert-type','info')); ?>";
        switch (type) {
            case 'info':
                toastr.info("<?php echo e(Session::get('message')); ?>");
                break;

            case 'success':
                toastr.success("<?php echo e(Session::get('message')); ?>");
                break;

            case 'warning':
                toastr.warning("<?php echo e(Session::get('message')); ?>");
                break;

            case 'error':
                toastr.error("<?php echo e(Session::get('message')); ?>");
                break;
        }
    </script>
<?php endif; ?>

<!--End Toaster alert--><?php /**PATH H:\Workspacce\Projects\Laravel\ecom\resources\views/admin/body/footer.blade.php ENDPATH**/ ?>