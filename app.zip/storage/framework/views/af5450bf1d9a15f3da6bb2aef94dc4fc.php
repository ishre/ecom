
<?php $__env->startSection('admin'); ?>


<div class="page-content">

    <div class="row profile-body">
        <!-- left wrapper start -->
        <div class="col-md-4 col-xl-4 left-wrapper">
            <div class=" card rounded">
                <div class="card-body">
                    <div class="d-flex align-items-center justify-content-between mb-2">
                        <h6 class="card-title mb-0">About</h6>
                    </div>
                    <div class="mt-3 mb-3">
                        <img class="wd-100 rounded-circle" src="<?php echo e((!empty($profileData->photo)) ? url('upload/admin_images/'.$profileData->photo) : url('https://static.vecteezy.com/system/resources/previews/008/442/086/non_2x/illustration-of-human-icon-user-symbol-icon-modern-design-on-blank-background-free-vector.jpg')); ?> " alt="profile">
                    </div>
                    <div class="mb-3">
                        <span class="h4 mt-3"><?php echo e($profileData->name); ?></span>
                    </div>
                    <p>Hi! I'm Amiah the Senior UI Designer at NobleUI. We hope you enjoy the design and quality of Social.</p>
                    <div class="mt-3">
                        <label class="tx-11 fw-bolder mb-0 text-uppercase">Username:</label>
                        <p class="text-muted"><span>@</span><?php echo e($profileData->username); ?></p>
                    </div>
                    <div class="mt-3">
                        <label class="tx-11 fw-bolder mb-0 text-uppercase">Email:</label>
                        <p class="text-muted"><?php echo e($profileData->email); ?></p>
                    </div>
                    <div class="mt-3">
                        <label class="tx-11 fw-bolder mb-0 text-uppercase">Phone:</label>
                        <p class="text-muted"><?php echo e($profileData->phone); ?></p>
                    </div>
                    <div class="mt-3">
                        <label class="tx-11 fw-bolder mb-0 text-uppercase">Address:</label>
                        <p class="text-muted"><?php echo e($profileData->address); ?></p>
                    </div>

                    <div class="mt-3 d-flex social-links">
                        <a href="javascript:;" class="btn btn-icon border btn-xs me-2">
                            <i data-feather="github"></i>
                        </a>
                        <a href="javascript:;" class="btn btn-icon border btn-xs me-2">
                            <i data-feather="twitter"></i>
                        </a>
                        <a href="javascript:;" class="btn btn-icon border btn-xs me-2">
                            <i data-feather="instagram"></i>
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <!-- left wrapper end -->
        <!-- middle wrapper start -->
        <div class="col-md-8 col-xl-8 middle-wrapper">

            <div class="card">
                <div class="card-body">

                    <h6 class="card-title">Update Profile</h6>

                    <form class="forms-sample" method="POST" action="<?php echo e(route('admin.profile.store')); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <label for="name" class="form-label">Name</label>
                            <input name="name" type="text" class="form-control" id="name" autocomplete="off" value="<?php echo e($profileData->name); ?>">
                        </div>
                        <div class="mb-3">
                            <label for="username" class="form-label">Username</label>
                            <input name="username" type="text" class="form-control" id="username" autocomplete="off" value="<?php echo e($profileData->username); ?>">
                        </div>
                        <div class="mb-3">
                            <label for="email" class="form-label">Email address</label>
                            <input name="email" type="email" class="form-control" id="email" value="<?php echo e($profileData->email); ?>">
                        </div>
                        <div class="mb-3">
                            <label for="address" class="form-label">Address</label>
                            <input name="address" type="textarea" class="form-control" id="address" value="<?php echo e($profileData->address); ?>">
                        </div>
                        <div class="mb-3">
                            <label class="form-label" for="photo">File upload</label>
                            <input name="photo" class="form-control" type="file" id="image">
                        </div>
                        <div class="mt-3 mb-3">
                            <img class="wd-80 rounded-circle" id="showImage" src="<?php echo e((!empty($profileData->photo)) ? url('upload/admin_images/'.$profileData->photo) : url('https://static.vecteezy.com/system/resources/previews/008/442/086/non_2x/illustration-of-human-icon-user-symbol-icon-modern-design-on-blank-background-free-vector.jpg')); ?> " alt="profile">
                        </div>
                        <button type="submit" class="btn btn-primary me-2">Submit</button>
                        <button class="btn btn-secondary">Cancel</button>
                    </form>

                </div>
            </div>
        </div>

        <!-- middle wrapper end -->
    </div>

</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
<script type="text/javascript">
    $(document).ready(function(){
        $('#image').change(function(e){
            var reader = new FileReader();
            reader.onload = function(e){
                $('#showImage').attr('src',e.target.result);
            }
            reader.readAsDataURL(e.target.files['0']);
        })
    })
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.admin_dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\Workspacce\Projects\Laravel\ecom\resources\views/admin/admin_profile_view.blade.php ENDPATH**/ ?>