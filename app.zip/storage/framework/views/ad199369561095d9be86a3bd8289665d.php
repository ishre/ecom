[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH H:\Workspacce\Projects\Laravel\ecom\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/header.blade.php ENDPATH**/ ?>